# -*- coding: utf-8 -*-
import random

class Graph:
    def __init__(self, L): 
    # vertices are labeled from 0 to n-1  
    # L[i] gives the list of neighbours of vertex i
        self.L=L
        self.n=len(L)

    # draws a random neighbour of vertex i
    def random_neighbour(self,i):
        pass  
        
    # draws a random walk of length k, starting from 0    
    def random_walk(self,k):
        pass
    
    # draws a random walk (starting from 0) till all vertices are visited    
    def random_walk_till_covered(self):
        pass
     
    # draws a random spanning tree
    def random_tree(self):
        pass